// Définir une icône personnalisée avec l'emoji 🌳
const treeIcon = L.divIcon({
    className: 'custom-tree-icon', // Classe CSS personnalisée
    html: '🌳', // Emoji utilisé comme contenu HTML
    iconSize: [32, 32], // Taille de l'icône
    iconAnchor: [16, 32], // Point d'ancrage (centre bas)
});

// Initialisation de la carte
const map = L.map('map').setView([48.649, -2.025], 13);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors'
}).addTo(map);

// Liste des arbres (stockage local)
let arbres = JSON.parse(localStorage.getItem('arbres')) || [];
let markersLayer = L.layerGroup().addTo(map);

// Fonction pour afficher les arbres sur la carte et dans la liste
function afficherArbres() {
    markersLayer.clearLayers();

    const treeList = document.getElementById('tree-list');
    treeList.innerHTML = '';

    arbres.forEach((arbre, index) => {
        // Créer un marqueur avec l'icône personnalisée
        const marker = L.marker([arbre.latitude, arbre.longitude], { icon: treeIcon })
            .bindPopup(`
                <div style="text-align: center;">
                    <h4>${arbre.nom}</h4>
                    <p>Espèce : ${arbre.espece}</p>
                    <p>Latitude : ${arbre.latitude.toFixed(5)}</p>
                    <p>Longitude : ${arbre.longitude.toFixed(5)}</p>
                </div>
            `);
        markersLayer.addLayer(marker);

        // Ajouter l'arbre à la liste HTML
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${arbre.nom}</td>
            <td>${arbre.espece}</td>
            <td><button class='btn btn-danger btn-sm' onclick='supprimerArbre(${index})'>Supprimer</button></td>`;
        treeList.appendChild(row);
    });

    document.getElementById('total-arbres').textContent = arbres.length; // Met à jour le compteur
}

// Événement : Clic sur la carte pour ajouter un arbre
map.on('click', function(e) {
    const { lat, lng } = e.latlng;

    const nom = prompt("Entrez le nom de l'arbre :", "Nouvel Arbre");
    const espece = prompt("Entrez l'espèce de l'arbre :", "Espèce inconnue");

    if (nom && espece) {
        const nouvelArbre = { nom, espece, latitude: lat, longitude: lng };
        arbres.push(nouvelArbre);
        localStorage.setItem('arbres', JSON.stringify(arbres));
        afficherArbres();
        alert(`L'arbre "${nom}" a été ajouté avec succès !`);
    }
});

// Fonction pour supprimer un arbre
function supprimerArbre(index) {
    if (confirm("Voulez-vous vraiment supprimer cet arbre ?")) {
        arbres.splice(index, 1);
        localStorage.setItem('arbres', JSON.stringify(arbres));
        afficherArbres();
    }
}

// Afficher les arbres existants au chargement de la page
afficherArbres();
